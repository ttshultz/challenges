To adjust the number of games to play
-------------------------------------
Change the value of the "gamesToPlay" variable in wopr.dart

To Run the Game
---------------
Run wopr.exe
Then use "dart wopr.dart" or runme.bat
(You can just run these sequentially from file explorer)

